/*
 * Generated S-function Target for model Rad. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Mon Jan 16 11:02:57 2017
 */

#include "Rad_sf.h"
#include "Rad_sfcn_rtw\Rad_sf.c"
#include "Rad_sfcn_rtw\Rad_sf_data.c"


