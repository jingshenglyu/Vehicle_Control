/*
* Generated S-function Target for model Rad. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Mon Jan 16 11:02:57 2017
*/

#ifndef RTWSFCN_Rad_sf_H
#define RTWSFCN_Rad_sf_H

#include "Rad_sfcn_rtw\Rad_sf.h"
  #include "Rad_sfcn_rtw\Rad_sf_private.h"

#endif
