/*
 * Generated S-function Target for model c_alpha. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Mon Jan 16 11:02:07 2017
 */

#include "c_alpha_sf.h"
#include "c_alpha_sfcn_rtw\c_alpha_sf.c"


